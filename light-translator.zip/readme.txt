=== Light Translator ===
Contributors: Tu Nombre
Tags: traducción, texto, reemplazar, global
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 1.0.0
License: GPL2

== Description ==

Light Translator es un plugin simple para reemplazar textos específicos en tu sitio web con traducciones personalizadas. Puedes agregar traducciones globales que afecten a todo el sitio web.

== Installation ==

1. Subir el plugin a tu servidor.
2. Activar el plugin desde el panel de administración de WordPress.
3. Agregar traducciones desde la página "Light Translator" en el menú de administración.

== Changelog ==

= 1.0.0 =
* Primera versión estable.
* Funcionalidad para agregar traducciones globales.
